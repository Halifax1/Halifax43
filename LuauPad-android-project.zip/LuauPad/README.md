# Luau Pad (Android)

A WebView app that wraps the Luau Pad editor (app/src/main/assets/index.html).

## Get the APK without installing anything

1. Create a free GitHub account and a new repository.
2. Upload every file and folder from this project, keeping the folder layout.
   Make sure the hidden folder .github/workflows is included.
3. Open the repository's Actions tab. The "Build APK" workflow runs on its own
   (or choose it and tap Run workflow).
4. When it finishes, open the run and download the LuauPad-apk artifact.
   Unzip it to get app-debug.apk.
5. Open the APK on your phone and allow installs from your browser or file manager.

## Or build it in Android Studio

Open this folder in Android Studio and choose Build > Build APK(s).
